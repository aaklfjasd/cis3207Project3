//
//  open_listenfd.h
//  
//
//  Created by Leo Vergnetti on 11/2/18.
//

#ifndef open_listenfd_h
#define open_listenfd_h

int open_listenfd(int port);

#endif /* open_listenfd_h */
